import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { ProjectsSection } from './components/ProjectsSection';
import { SkillsSection } from './components/SkillsSection';
import { ContactSection } from './components/ContactSection';
import { ProjectDetail } from './components/ProjectDetail';

export default function App() {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  if (selectedProject !== null) {
    return (
      <div className="bg-white min-h-screen">
        <Navigation onBackClick={() => setSelectedProject(null)} showBack />
        <ProjectDetail projectId={selectedProject} onClose={() => setSelectedProject(null)} />
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen">
      <Navigation />
      <HeroSection />
      <ProjectsSection onProjectClick={setSelectedProject} />
      <SkillsSection />
      <ContactSection />
    </div>
  );
}
