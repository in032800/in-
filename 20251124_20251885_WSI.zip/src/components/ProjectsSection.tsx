import { ArrowUpRight } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    description: '곡선 기반 내비게이션과 유기적 레이아웃',
    year: '2024',
    tags: ['React', 'TypeScript', 'Framer Motion'],
  },
  {
    id: 2,
    title: 'Design System',
    description: '자연의 기하학에서 영감받은 컴포넌트 시스템',
    year: '2024',
    tags: ['Storybook', 'Tailwind', 'Figma'],
  },
  {
    id: 3,
    title: 'Data Visualization',
    description: '육각형 그리드를 활용한 데이터 대시보드',
    year: '2023',
    tags: ['D3.js', 'Next.js', 'WebGL'],
  },
  {
    id: 4,
    title: 'Mobile Experience',
    description: '비대칭적 섹션 분할과 곡선 UI',
    year: '2023',
    tags: ['React Native', 'Animation'],
  },
  {
    id: 5,
    title: 'Portfolio Builder',
    description: '모자이크 스타일 이미지 그리드 시스템',
    year: '2023',
    tags: ['Vue', 'Canvas', 'GSAP'],
  },
  {
    id: 6,
    title: 'Creative Studio',
    description: '3D 공간과 유기적 형태의 결합',
    year: '2022',
    tags: ['Three.js', 'React', 'Blender'],
  },
];

interface ProjectsSectionProps {
  onProjectClick: (id: number) => void;
}

export function ProjectsSection({ onProjectClick }: ProjectsSectionProps) {
  return (
    <section id="projects" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">Selected Works</span>
          <h2 className="text-neutral-950">Projects</h2>
          <p className="text-neutral-600 mt-4 max-w-2xl">
            각 프로젝트는 문제의 본질을 탐구하고 구조적 해결책을 찾는 과정입니다.
            <br />
            클릭하여 상세한 사고 과정과 의사결정을 확인하세요.
          </p>
        </div>

        {/* Asymmetric grid - Gaudi inspired */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {projects.map((project, index) => {
            const isLarge = index % 3 === 0;
            const colSpan = isLarge ? 'lg:col-span-8' : 'lg:col-span-4';
            
            return (
              <button
                key={project.id}
                onClick={() => onProjectClick(project.id)}
                className={`group relative ${colSpan} text-left`}
              >
                <div className="relative h-full min-h-[400px] bg-neutral-100 overflow-hidden cursor-pointer">
                  {/* Image placeholder with subtle gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-neutral-100 to-neutral-200 group-hover:scale-105 transition-transform duration-700" />
                  
                  {/* Organic overlay shape */}
                  <div 
                    className="absolute inset-0 bg-neutral-950/80 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  >
                    <div className="absolute inset-0 flex flex-col justify-between p-8">
                      <div>
                        <span className="text-xs text-neutral-400 uppercase tracking-wider mb-4 block">
                          {project.year}
                        </span>
                        <h3 className="text-white mb-3">{project.title}</h3>
                        <p className="text-neutral-300 mb-6">{project.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {project.tags.map((tag) => (
                            <span
                              key={tag}
                              className="text-xs text-neutral-400 border border-neutral-700 px-3 py-1"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-white">
                        <span className="text-sm">View Case Study</span>
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  {/* Bottom info bar */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/50 to-transparent group-hover:opacity-0 transition-opacity">
                    <h3 className="text-white">{project.title}</h3>
                  </div>

                  {/* Decorative corner element */}
                  <div className="absolute top-6 right-6 w-12 h-12 border-t border-r border-neutral-950/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
