import { Mail, Linkedin, Github, Twitter, ArrowUpRight } from 'lucide-react';

export function ContactSection() {
  return (
    <section id="contact" className="py-32 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-24 items-start">
          {/* Left - Contact Info */}
          <div>
            <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">Get In Touch</span>
            <h2 className="text-neutral-950 mb-8">Let's Work Together</h2>
            
            <p className="text-xl text-neutral-600 mb-12 leading-relaxed">
              자연스러운 형태와 현대적 기술의 조화로
              <br />
              의미있는 프로젝트를 함께 만들어갑니다
            </p>

            {/* Contact Links */}
            <div className="space-y-6 mb-16">
              <a href="mailto:hello@example.com" className="group flex items-center gap-4 text-neutral-950 hover:text-neutral-600 transition-colors">
                <div className="w-12 h-12 border border-neutral-200 flex items-center justify-center group-hover:border-neutral-950 transition-colors">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-neutral-500 mb-1">Email</p>
                  <p>hello@example.com</p>
                </div>
                <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>

              <a href="tel:+82-10-1234-5678" className="group flex items-center gap-4 text-neutral-950 hover:text-neutral-600 transition-colors">
                <div className="w-12 h-12 border border-neutral-200 flex items-center justify-center group-hover:border-neutral-950 transition-colors">
                  <span className="text-xl">📱</span>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 mb-1">Phone</p>
                  <p>+82 10 1234 5678</p>
                </div>
                <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>

            {/* Social Links with Hexagonal shapes */}
            <div>
              <p className="text-sm text-neutral-500 uppercase tracking-wider mb-6">Connect</p>
              <div className="flex gap-4">
                {[
                  { icon: Linkedin, href: '#', label: 'LinkedIn' },
                  { icon: Github, href: '#', label: 'GitHub' },
                  { icon: Twitter, href: '#', label: 'Twitter' },
                  { icon: Mail, href: '#', label: 'Email' },
                ].map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.label}
                      href={social.href}
                      aria-label={social.label}
                      className="group relative"
                    >
                      <div
                        className="w-12 h-12 bg-neutral-950 flex items-center justify-center text-white hover:bg-neutral-700 transition-colors"
                        style={{
                          clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)',
                        }}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right - Contact Form */}
          <div className="lg:pt-20">
            <form className="space-y-6">
              <div>
                <label className="block text-sm text-neutral-950 mb-2">Name</label>
                <input
                  type="text"
                  className="w-full px-0 py-3 bg-transparent border-b border-neutral-200 focus:border-neutral-950 focus:outline-none transition-colors text-neutral-950"
                  placeholder="Your name"
                />
              </div>

              <div>
                <label className="block text-sm text-neutral-950 mb-2">Email</label>
                <input
                  type="email"
                  className="w-full px-0 py-3 bg-transparent border-b border-neutral-200 focus:border-neutral-950 focus:outline-none transition-colors text-neutral-950"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label className="block text-sm text-neutral-950 mb-2">Project Type</label>
                <select className="w-full px-0 py-3 bg-transparent border-b border-neutral-200 focus:border-neutral-950 focus:outline-none transition-colors text-neutral-950">
                  <option>Web Development</option>
                  <option>UI/UX Design</option>
                  <option>Creative Coding</option>
                  <option>Consultation</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-neutral-950 mb-2">Message</label>
                <textarea
                  rows={4}
                  className="w-full px-0 py-3 bg-transparent border-b border-neutral-200 focus:border-neutral-950 focus:outline-none transition-colors resize-none text-neutral-950"
                  placeholder="Tell me about your project..."
                />
              </div>

              <div className="pt-6">
                <button
                  type="submit"
                  className="group w-full bg-neutral-950 text-white py-4 hover:bg-neutral-800 transition-colors flex items-center justify-between px-8"
                >
                  <span>Send Message</span>
                  <ArrowUpRight className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-32 pt-12 border-t border-neutral-200 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <div 
              className="w-8 h-8 bg-neutral-950"
              style={{ clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}
            />
            <p className="text-sm text-neutral-500">
              Inspired by Antoni Gaudí's organic architecture
            </p>
          </div>
          <p className="text-sm text-neutral-400">
            © 2024 All rights reserved
          </p>
        </div>
      </div>
    </section>
  );
}