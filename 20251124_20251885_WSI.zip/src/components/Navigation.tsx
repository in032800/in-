import { useState, useEffect } from 'react';
import { Menu, X, ArrowLeft } from 'lucide-react';

interface NavigationProps {
  onBackClick?: () => void;
  showBack?: boolean;
}

export function Navigation({ onBackClick, showBack = false }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo / Back button */}
          <div className="flex items-center gap-4">
            {showBack && onBackClick ? (
              <button
                onClick={onBackClick}
                className="flex items-center gap-2 text-neutral-950 hover:text-neutral-600 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 bg-neutral-950"
                  style={{ clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}
                />
                <span className={`transition-colors ${isScrolled ? 'text-neutral-950' : 'text-white'}`}>
                  Portfolio
                </span>
              </div>
            )}
          </div>

          {/* Desktop Navigation */}
          {!showBack && (
            <>
              <div className="hidden md:flex items-center gap-8">
                <button
                  onClick={() => scrollToSection('projects')}
                  className={`text-sm transition-colors hover:text-neutral-600 ${
                    isScrolled ? 'text-neutral-950' : 'text-white'
                  }`}
                >
                  Work
                </button>
                <button
                  onClick={() => scrollToSection('skills')}
                  className={`text-sm transition-colors hover:text-neutral-600 ${
                    isScrolled ? 'text-neutral-950' : 'text-white'
                  }`}
                >
                  About
                </button>
                <button
                  onClick={() => scrollToSection('contact')}
                  className={`text-sm transition-colors hover:text-neutral-600 ${
                    isScrolled ? 'text-neutral-950' : 'text-white'
                  }`}
                >
                  Contact
                </button>
                <div className="w-px h-4 bg-neutral-300" />
                <button className="text-sm px-6 py-2 border border-neutral-950 text-neutral-950 hover:bg-neutral-950 hover:text-white transition-colors">
                  Resume
                </button>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={`md:hidden transition-colors ${isScrolled ? 'text-neutral-950' : 'text-white'}`}
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </>
          )}
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && !showBack && (
          <div className="md:hidden pt-6 pb-4 space-y-4">
            <button
              onClick={() => scrollToSection('projects')}
              className="block w-full text-left text-neutral-950 hover:text-neutral-600 transition-colors"
            >
              Work
            </button>
            <button
              onClick={() => scrollToSection('skills')}
              className="block w-full text-left text-neutral-950 hover:text-neutral-600 transition-colors"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block w-full text-left text-neutral-950 hover:text-neutral-600 transition-colors"
            >
              Contact
            </button>
            <button className="w-full text-left px-6 py-2 border border-neutral-950 text-neutral-950 hover:bg-neutral-950 hover:text-white transition-colors">
              Resume
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
