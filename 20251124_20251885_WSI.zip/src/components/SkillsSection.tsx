import { WaveDivider } from './WaveDivider';

const skills = [
  { name: 'React', level: 95 },
  { name: 'TypeScript', level: 90 },
  { name: 'Next.js', level: 88 },
  { name: 'UI/UX Design', level: 92 },
  { name: 'Tailwind CSS', level: 95 },
  { name: 'Framer Motion', level: 85 },
  { name: 'Three.js', level: 78 },
  { name: 'Node.js', level: 82 },
];

const services = [
  {
    number: '01',
    title: 'Web Development',
    description: '반응형 웹 애플리케이션과 인터랙티브 경험 개발',
  },
  {
    number: '02',
    title: 'UI/UX Design',
    description: '사용자 중심의 인터페이스와 유기적 디자인 시스템',
  },
  {
    number: '03',
    title: 'Creative Coding',
    description: '애니메이션과 3D 그래픽을 활용한 창의적 구현',
  },
];

export function SkillsSection() {
  return (
    <section id="skills" className="relative bg-neutral-50">
      {/* Top Wave */}
      <div className="absolute top-0 left-0 right-0 h-20 -mt-px">
        <WaveDivider fill="#fafafa" flip subtle />
      </div>

      <div className="py-32 px-6 pt-40">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-24 items-start">
            {/* Skills with organic bars */}
            <div>
              <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">Expertise</span>
              <h2 className="text-neutral-950 mb-12">Skills</h2>

              <div className="space-y-8">
                {skills.map((skill, index) => (
                  <div key={skill.name} className="group">
                    <div className="flex justify-between mb-3">
                      <span className="text-neutral-950">{skill.name}</span>
                      <span className="text-neutral-400">{skill.level}%</span>
                    </div>
                    <div className="relative h-1 bg-neutral-200 overflow-hidden">
                      {/* Organic wave progress bar */}
                      <div 
                        className="absolute inset-y-0 left-0 bg-neutral-950 transition-all duration-1000 ease-out"
                        style={{ 
                          width: `${skill.level}%`,
                          clipPath: 'polygon(0 0, 98% 0, 100% 50%, 98% 100%, 0 100%)'
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Services */}
            <div className="lg:pt-32">
              <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">What I Do</span>
              <h2 className="text-neutral-950 mb-12">Services</h2>

              <div className="space-y-12">
                {services.map((service) => (
                  <div key={service.number} className="group cursor-pointer">
                    <div className="flex items-start gap-6">
                      <span className="text-5xl font-light text-neutral-300 group-hover:text-neutral-950 transition-colors">
                        {service.number}
                      </span>
                      <div className="flex-1 pt-2">
                        <h3 className="text-neutral-950 mb-2 group-hover:translate-x-2 transition-transform">
                          {service.title}
                        </h3>
                        <p className="text-neutral-600">
                          {service.description}
                        </p>
                      </div>
                    </div>
                    {/* Organic underline */}
                    <div className="mt-6 h-px bg-neutral-200 relative overflow-hidden">
                      <div className="absolute inset-0 bg-neutral-950 -translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Experience with hexagonal timeline */}
          <div className="mt-32 pt-32 border-t border-neutral-200">
            <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">Journey</span>
            <h2 className="text-neutral-950 mb-16">Experience</h2>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                { year: '2024', role: 'Senior Designer', company: 'Studio A', location: 'Seoul' },
                { year: '2022', role: 'UI/UX Designer', company: 'Agency B', location: 'Seoul' },
                { year: '2020', role: 'Junior Designer', company: 'Startup C', location: 'Seoul' },
              ].map((exp) => (
                <div key={exp.year} className="group relative">
                  {/* Hexagonal accent */}
                  <div 
                    className="absolute -top-4 -left-4 w-8 h-8 bg-neutral-950 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}
                  />
                  
                  <div className="border border-neutral-200 p-8 group-hover:border-neutral-950 transition-colors">
                    <span className="text-4xl text-neutral-950 mb-6 block">{exp.year}</span>
                    <h4 className="text-neutral-950 mb-2">{exp.role}</h4>
                    <p className="text-neutral-600 mb-1">{exp.company}</p>
                    <p className="text-sm text-neutral-400">{exp.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0 h-20 -mb-px">
        <WaveDivider fill="#ffffff" subtle />
      </div>
    </section>
  );
}