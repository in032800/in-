interface WaveDividerProps {
  className?: string;
  fill?: string;
  flip?: boolean;
  subtle?: boolean;
}

export function WaveDivider({ className = '', fill = '#ffffff', flip = false, subtle = false }: WaveDividerProps) {
  const path = subtle 
    ? "M0,60 C300,100 900,20 1200,60 L1200,120 L0,120 Z"
    : "M0,50 C200,90 400,10 600,50 C800,90 1000,10 1200,50 L1200,120 L0,120 Z";
    
  return (
    <div className={`w-full ${className}`} style={{ transform: flip ? 'scaleY(-1)' : 'none' }}>
      <svg
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        className="w-full h-full"
      >
        <path d={path} fill={fill} />
      </svg>
    </div>
  );
}
