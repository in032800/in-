import { ArrowRight, ExternalLink, Github } from 'lucide-react';

interface ProjectDetailProps {
  projectId: number;
  onClose: () => void;
}

const projectData: Record<number, any> = {
  1: {
    title: 'E-Commerce Platform',
    subtitle: '곡선 기반 내비게이션과 유기적 레이아웃',
    year: '2024',
    client: 'Fashion Retail Company',
    role: 'Lead Designer & Developer',
    tags: ['React', 'TypeScript', 'Framer Motion', 'Tailwind CSS'],
    
    challenge: '기존 전자상거래 플랫폼은 직선적이고 경직된 레이아웃으로 인해 사용자가 제품을 탐색하는 과정이 지루하고 기계적이었습니다. 브랜드의 유기적이고 자연스러운 철학을 온라인 경험에 반영해야 했습니다.',
    
    approach: [
      {
        title: '1. 사용자 흐름 연구',
        description: '가우디의 포물선 아치처럼, 사용자의 시선과 손가락 움직임의 자연스러운 궤적을 연구했습니다. 히트맵 데이터와 사용자 테스트를 통해 곡선 기반 내비게이션이 직선보다 15% 더 직관적임을 발견했습니다.',
      },
      {
        title: '2. 구조적 합리성',
        description: '단순히 보기 좋은 곡선이 아닌, 기능적 목적이 있는 곡선을 설계했습니다. 카테고리 전환 시 곡선 애니메이션은 사용자의 시선을 자연스럽게 유도하며, 인지 부하를 줄입니다.',
      },
      {
        title: '3. 반응형 유기체',
        description: '가우디의 건축물이 주변 환경에 반응하듯, 레이아웃은 화면 크기, 사용자 행동, 콘텐츠 양에 따라 유기적으로 변형됩니다. CSS Grid의 minmax()와 clamp()를 활용한 유동적 타이포그래피를 구현했습니다.',
      },
    ],
    
    solution: '곡선 기반 내비게이션 시스템, 비대칭 그리드 레이아웃, 그리고 제스처 기반 인터랙션을 결합하여 전환율을 23% 향상시켰습니다. 사용자 테스트에서 "자연스럽다", "편안하다"는 피드백이 78% 증가했습니다.',
    
    metrics: [
      { label: '전환율 증가', value: '+23%' },
      { label: '평균 세션 시간', value: '+45%' },
      { label: '이탈률 감소', value: '-18%' },
      { label: '사용자 만족도', value: '4.7/5' },
    ],
    
    learnings: [
      '미학과 기능의 균형: 곡선은 아름다울 뿐만 아니라 사용자의 인지 과정을 돕는 도구입니다.',
      '성능 최적화: 복잡한 애니메이션은 GPU 가속과 will-change 속성으로 60fps를 유지했습니다.',
      '접근성: 키보드 내비게이션과 스크린 리더 호환성을 유지하면서 독창적 UI를 구현하는 것의 중요성을 배웠습니다.',
    ],
  },
  2: {
    title: 'Design System',
    subtitle: '자연의 기하학에서 영감받은 컴포넌트 시스템',
    year: '2024',
    client: 'Tech Startup',
    role: 'Design System Architect',
    tags: ['Storybook', 'Tailwind', 'Figma', 'React'],
    
    challenge: '여러 제품 팀이 각자 다른 스타일로 개발하여 브랜드 일관성이 부족했습니다. 가우디의 통일성 철학처럼, 모든 컴포넌트가 하나의 언어로 소통하는 시스템이 필요했습니다.',
    
    approach: [
      {
        title: '1. 자연의 비율 체계',
        description: '가우디가 자연의 황금비를 사용했듯, 피보나치 수열을 기반으로 한 spacing scale(8, 13, 21, 34, 55px)을 정의했습니다. 이는 시각적 조화와 예측 가능성을 동시에 제공합니다.',
      },
      {
        title: '2. 유기적 컴포넌트',
        description: 'Button, Input, Card 등 모든 컴포넌트가 미묘한 곡선을 가지며, hover/focus 상태에서 "숨쉬는" 듯한 애니메이션을 적용했습니다. 하드코딩이 아닌 CSS 변수로 제어하여 일관성을 유지합니다.',
      },
      {
        title: '3. 문서화의 디테일',
        description: '가우디의 정교한 조각처럼, 각 컴포넌트의 사용 이유, 접근성 가이드, 성능 고려사항을 Storybook에 상세히 기록했습니다. "어떻게"뿐만 아니라 "왜"를 설명합니다.',
      },
    ],
    
    solution: '60개 이상의 컴포넌트와 명확한 가이드라인으로 구성된 디자인 시스템을 구축했습니다. 개발 시간을 40% 단축하고, 브랜드 일관성을 크게 개선했습니다.',
    
    metrics: [
      { label: '개발 속도', value: '+40%' },
      { label: '디자인 QA 이슈', value: '-65%' },
      { label: '컴포넌트 재사용률', value: '87%' },
      { label: '팀 만족도', value: '4.8/5' },
    ],
    
    learnings: [
      '토큰 기반 설계: 색상, 간격, 타이포그래피를 모두 토큰화하여 일관성과 유지보수성을 극대화했습니다.',
      '점진적 도입: 기존 코드를 한 번에 바꾸지 않고, 새 컴포넌트부터 적용하여 리스크를 줄였습니다.',
      '커뮤니티 참여: 디자이너와 개발자가 함께 컴포넌트를 제안하고 개선하는 문화를 만들었습니다.',
    ],
  },
  3: {
    title: 'Data Visualization',
    subtitle: '육각형 그리드를 활용한 데이터 대시보드',
    year: '2023',
    client: 'Analytics Company',
    role: 'Frontend Developer',
    tags: ['D3.js', 'Next.js', 'WebGL', 'TypeScript'],
    
    challenge: '복잡한 데이터를 직관적으로 표현하면서도 시각적으로 흥미로운 대시보드를 만들어야 했습니다. 전통적인 막대/선 그래프는 지루하고 정보 밀도가 낮았습니다.',
    
    approach: [
      {
        title: '1. 육각형의 효율성',
        description: '가우디가 육각형을 선호한 이유는 구조적 효율성입니다. 육각형 타일링은 같은 면적에 더 많은 데이터 포인트를 표시하며, 인접 셀 간의 거리가 균일합니다.',
      },
      {
        title: '2. 계층적 정보 구조',
        description: '큰 육각형 안에 작은 육각형들이 중첩되어 데이터의 계층을 표현합니다. 줌 인/아웃 시 부드러운 모핑 애니메이션으로 맥락을 유지합니다.',
      },
      {
        title: '3. 성능 최적화',
        description: '10,000개 이상의 데이터 포인트를 표시하기 위해 Canvas 렌더링과 가상 스크롤링을 구현했습니다. WebGL로 GPU 가속을 활용하여 60fps를 유지합니다.',
      },
    ],
    
    solution: '육각형 히트맵과 인터랙티브 필터링 시스템으로 사용자가 데이터 패턴을 3배 빠르게 발견할 수 있게 되었습니다.',
    
    metrics: [
      { label: '인사이트 발견 시간', value: '-67%' },
      { label: '데이터 밀도', value: '+150%' },
      { label: '렌더링 성능', value: '60fps' },
      { label: '사용자 참여도', value: '+89%' },
    ],
    
    learnings: [
      '형태의 기능성: 육각형은 단순히 독특한 모양이 아니라, 데이터 시각화에 최적화된 구조입니다.',
      '점진적 복잡성: 초기 뷰는 단순하게 시작하여, 사용자가 필요에 따라 더 깊이 들어갈 수 있도록 설계했습니다.',
      '색상의 과학: 색각 이상자를 고려한 색상 팔레트 선택으로 접근성을 개선했습니다.',
    ],
  },
};

export function ProjectDetail({ projectId, onClose }: ProjectDetailProps) {
  const project = projectData[projectId] || projectData[1];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 bg-neutral-950 text-white">
        <div className="max-w-5xl mx-auto">
          <span className="text-sm text-neutral-400 uppercase tracking-wider mb-6 block">
            {project.year} — {project.client}
          </span>
          <h1 className="mb-6">{project.title}</h1>
          <p className="text-2xl text-neutral-300 mb-12 max-w-3xl">
            {project.subtitle}
          </p>

          <div className="grid md:grid-cols-3 gap-8 pt-12 border-t border-neutral-800">
            <div>
              <p className="text-sm text-neutral-500 mb-2">Role</p>
              <p className="text-neutral-200">{project.role}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500 mb-2">Year</p>
              <p className="text-neutral-200">{project.year}</p>
            </div>
            <div>
              <p className="text-sm text-neutral-500 mb-2">Client</p>
              <p className="text-neutral-200">{project.client}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mt-8">
            {project.tags.map((tag: string) => (
              <span key={tag} className="px-4 py-2 border border-neutral-700 text-neutral-300 text-sm">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Main Image Placeholder */}
      <section className="h-[60vh] bg-neutral-200">
        <div className="w-full h-full bg-gradient-to-br from-neutral-200 to-neutral-300 flex items-center justify-center">
          <p className="text-neutral-400">Project Image</p>
        </div>
      </section>

      {/* Challenge */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-neutral-950 mb-6">The Challenge</h2>
          <p className="text-xl text-neutral-700 leading-relaxed">
            {project.challenge}
          </p>
        </div>
      </section>

      {/* Approach - Deep Research */}
      <section className="py-20 px-6 bg-neutral-50">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <span className="text-sm text-neutral-500 uppercase tracking-wider mb-4 block">
              깊은 연구와 구조적 고민
            </span>
            <h2 className="text-neutral-950">Approach</h2>
            <p className="text-neutral-600 mt-4">
              가우디가 포물선 아치를 선택한 데에는 합리적 이유가 있었습니다.
              <br />
              각 디자인 결정의 배경과 사고 과정을 투명하게 공유합니다.
            </p>
          </div>

          <div className="space-y-16">
            {project.approach.map((step: any, index: number) => (
              <div key={index} className="relative">
                {/* Connecting line */}
                {index < project.approach.length - 1 && (
                  <div className="absolute left-6 top-16 bottom-0 w-px bg-neutral-200" />
                )}
                
                <div className="flex gap-6">
                  {/* Hexagonal number */}
                  <div
                    className="flex-shrink-0 w-12 h-12 bg-neutral-950 text-white flex items-center justify-center relative z-10"
                    style={{ clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}
                  >
                    <span>{index + 1}</span>
                  </div>

                  <div className="flex-1 pt-1">
                    <h3 className="text-neutral-950 mb-3">{step.title}</h3>
                    <p className="text-neutral-700 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-neutral-950 mb-6">The Solution</h2>
          <p className="text-xl text-neutral-700 leading-relaxed mb-12">
            {project.solution}
          </p>

          {/* Metrics - Detailed outcomes */}
          <div className="grid md:grid-cols-4 gap-6">
            {project.metrics.map((metric: any) => (
              <div key={metric.label} className="border border-neutral-200 p-6 hover:border-neutral-950 transition-colors">
                <p className="text-4xl text-neutral-950 mb-2">{metric.value}</p>
                <p className="text-sm text-neutral-600">{metric.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Images Placeholder */}
      <section className="py-20 px-6 bg-neutral-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-neutral-950 mb-12">Visual Process</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-video bg-neutral-200 flex items-center justify-center">
                <p className="text-neutral-400">Process Image {i}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Learnings & Reflection */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-neutral-950 mb-8">Key Learnings</h2>
          <div className="space-y-6">
            {project.learnings.map((learning: string, index: number) => (
              <div key={index} className="flex gap-4">
                <ArrowRight className="w-5 h-5 text-neutral-950 flex-shrink-0 mt-1" />
                <p className="text-neutral-700 leading-relaxed">{learning}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Links */}
      <section className="py-20 px-6 border-t border-neutral-200">
        <div className="max-w-4xl mx-auto flex gap-6">
          <button className="flex items-center gap-2 px-8 py-3 bg-neutral-950 text-white hover:bg-neutral-800 transition-colors">
            <ExternalLink className="w-5 h-5" />
            <span>Live Site</span>
          </button>
          <button className="flex items-center gap-2 px-8 py-3 border border-neutral-950 text-neutral-950 hover:bg-neutral-950 hover:text-white transition-colors">
            <Github className="w-5 h-5" />
            <span>View Code</span>
          </button>
        </div>
      </section>

      {/* Next Project */}
      <section className="py-20 px-6 bg-neutral-950 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-neutral-400 mb-4">Next Project</p>
          <button
            onClick={() => {
              const nextId = projectId < 3 ? projectId + 1 : 1;
              window.scrollTo(0, 0);
              setTimeout(() => onClose(), 100);
              setTimeout(() => {
                const event = new CustomEvent('openProject', { detail: nextId });
                window.dispatchEvent(event);
              }, 200);
            }}
            className="text-4xl hover:text-neutral-400 transition-colors"
          >
            {projectData[projectId < 3 ? projectId + 1 : 1]?.title}
          </button>
        </div>
      </section>
    </div>
  );
}
