import { WaveDivider } from './WaveDivider';
import { ArrowDown } from 'lucide-react';

export function HeroSection() {
  const scrollToProjects = () => {
    const element = document.getElementById('projects');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-neutral-950 text-white">
      {/* Subtle organic background shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl" />
        <div className="absolute bottom-40 left-20 w-[32rem] h-[32rem] bg-orange-600/5 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <div className="mb-12 inline-block relative">
          <div className="w-3 h-3 bg-amber-500 rounded-full absolute -top-2 -left-2 animate-pulse" />
          <div className="w-2 h-2 bg-orange-500 rounded-full absolute -bottom-3 -right-3 animate-pulse delay-75" />
        </div>

        <h1 className="mb-8 tracking-tight">
          Creative Developer
        </h1>

        <p className="text-xl text-neutral-400 mb-12 max-w-2xl mx-auto leading-relaxed">
          유기적 형태와 기하학의 조화로
          <br />
          자연스러운 디지털 경험을 설계합니다
        </p>

        <div className="flex gap-6 justify-center items-center">
          <button className="px-8 py-3 bg-white text-neutral-950 hover:bg-neutral-100 transition-colors">
            View Work
          </button>
          <button className="px-8 py-3 border border-neutral-700 hover:border-neutral-500 transition-colors">
            Contact
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <button 
        onClick={scrollToProjects}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce hover:text-neutral-400 transition-colors"
      >
        <span className="text-xs text-neutral-500 uppercase tracking-wider">Scroll</span>
        <ArrowDown className="w-4 h-4 text-neutral-600" />
      </button>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 right-0 h-20">
        <WaveDivider fill="#ffffff" subtle />
      </div>
    </section>
  );
}