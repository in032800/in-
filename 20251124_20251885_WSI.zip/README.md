
  # Gaudi Philosophy Portfolio Design

  This is a code bundle for Gaudi Philosophy Portfolio Design. The original project is available at https://www.figma.com/design/PMVw0dZnz4NdRJ2FDCvZJK/Gaudi-Philosophy-Portfolio-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  